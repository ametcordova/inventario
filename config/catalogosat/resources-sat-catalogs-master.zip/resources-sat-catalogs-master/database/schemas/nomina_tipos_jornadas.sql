CREATE TABLE IF NOT EXISTS "nomina_tipos_jornadas"(
  "id" text not null,
  "texto" text not null,
  PRIMARY KEY("id")
);
