CREATE TABLE IF NOT EXISTS "nomina_origenes_recursos"(
  "id" text not null,
  "texto" text not null,
  PRIMARY KEY("id")
);
