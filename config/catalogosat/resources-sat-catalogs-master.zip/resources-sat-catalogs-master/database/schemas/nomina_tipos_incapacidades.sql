CREATE TABLE IF NOT EXISTS "nomina_tipos_incapacidades"(
  "id" text not null,
  "texto" text not null,
  PRIMARY KEY("id")
);
