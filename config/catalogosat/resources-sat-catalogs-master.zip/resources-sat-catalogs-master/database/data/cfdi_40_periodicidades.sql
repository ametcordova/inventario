PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
INSERT INTO cfdi_40_periodicidades VALUES('01','Diario','2022-01-01','');
INSERT INTO cfdi_40_periodicidades VALUES('02','Semanal','2022-01-01','');
INSERT INTO cfdi_40_periodicidades VALUES('03','Quincenal','2022-01-01','');
INSERT INTO cfdi_40_periodicidades VALUES('04','Mensual','2022-01-01','');
INSERT INTO cfdi_40_periodicidades VALUES('05','Bimestral','2022-01-01','');
COMMIT;
