PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
INSERT INTO ccp_20_transportes VALUES('01','Autotransporte','2021-12-01','');
INSERT INTO ccp_20_transportes VALUES('02','Transporte Marítimo','2021-12-01','');
INSERT INTO ccp_20_transportes VALUES('03','Transporte Aéreo','2021-12-01','');
INSERT INTO ccp_20_transportes VALUES('04','Transporte Ferroviario','2021-12-01','');
COMMIT;
