PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
INSERT INTO ccp_20_figuras_transporte VALUES('01','Operador','2021-12-01','');
INSERT INTO ccp_20_figuras_transporte VALUES('02','Propietario','2021-12-01','');
INSERT INTO ccp_20_figuras_transporte VALUES('03','Arrendador','2021-12-01','');
INSERT INTO ccp_20_figuras_transporte VALUES('04','Notificado','2021-12-01','');
COMMIT;
