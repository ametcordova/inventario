PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
INSERT INTO pagos_tipos_cadena_pago VALUES('01','SPEI');
COMMIT;
