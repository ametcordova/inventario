PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
INSERT INTO cfdi_40_tipos_factores VALUES('Tasa','2022-01-01','');
INSERT INTO cfdi_40_tipos_factores VALUES('Cuota','2022-01-01','');
INSERT INTO cfdi_40_tipos_factores VALUES('Exento','2022-01-01','');
COMMIT;
